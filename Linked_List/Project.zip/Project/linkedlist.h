#include<fstream>
#include"node.cpp"
class LinkedList
{
	Node<Player> *start;
	public:
	LinkedList();
	void insertAtMid(Player&,int);
	void deleteAtMid(int);
	void searchByJersey();
	void searchByName();
	void updatePlayerInfo(int);
	void topRunner();
	void topWicketer();
	void display();
	void readFromFile(const char* );
	void writeToFile(const char*); 
	~LinkedList();
};



package com.dictionary_V1;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class Dictionary {

	Map<Character,Map<String,List<String>>> dictionary=new HashMap<>();

	public Map<Character, Map<String, List<String>>> getDictionary() {
		return dictionary;
	}

	public void setDictionary(Map<Character, Map<String, List<String>>> dictionary) {
		this.dictionary = dictionary;
	}

	public void addWordNdMeaning(String word,String meaning) {
		
		//word with meaning
		
		Map<String, List<String>> dict=this.dictionary.get(word.toLowerCase().charAt(0));
		if(dict!=null) {
			Set<String> w =dictionary.get(word.toLowerCase().charAt(0)).keySet();
			if(w.contains(word.toLowerCase()))
			{
				System.out.println("This Word already exist !");
			}
			else
			{
				dictionary.get(word.toLowerCase().charAt(0)).put(word.toLowerCase(),new ArrayList<>());				
				dictionary.get(word.toLowerCase().charAt(0)).get(word.toLowerCase()).add(meaning);
				System.out.println("Word Added Successfully!");
			}
		}
		else {
			this.dictionary.put(word.toLowerCase().charAt(0), new HashMap<>());
			dictionary.get(word.toLowerCase().charAt(0)).put(word.toLowerCase(),new ArrayList<>());
			dictionary.get(word.toLowerCase().charAt(0)).get(word.toLowerCase()).add(meaning);
			System.out.println("Word Added Successfully!");
		}
	}
	
	public void addMeaning(String word,String meaning) {
		Map<String, List<String>> dict=this.dictionary.get(word.toLowerCase().charAt(0));
		if(dict!=null) {
			List<String> l=dict.get(word.toLowerCase());
			if(l!=null) {
				l.add(meaning);
				System.out.println("Meaning Successfully Added");
			}
			else {
				//System.out.println("Word not found!");
				addWordNdMeaning(word,meaning);
			}
		}
		else {
			//System.out.println("There is no word to add meaning");
			addWordNdMeaning(word,meaning);
		}

	}
	
	public void display() {
	    try {
			Set<Entry<Character, Map<String, List<String>>>> dict=this.dictionary.entrySet();
			Iterator<Entry<Character, Map<String, List<String>>>> iot=dict.iterator();
			while(iot.hasNext()) {
				System.out.println(iot.next());
			}
		} catch (NullPointerException e) {
			System.out.println("Dictionary is empty!");
		}
	}
	
	public void search(String word) {
		
		try {
			Map<String,List<String>> wordMean=new HashMap<>();
			int flag=-1;
			Map<String,List<String>> words=this.dictionary.get(word.toLowerCase().charAt(0));
			for(Entry<String, List<String>> wm:words.entrySet()){
				if(wm.getKey().startsWith(word.toLowerCase())) {
					wordMean.put(wm.getKey(), wm.getValue());
					flag++;
				}
			}
			if(flag==-1) {
				System.out.println("Word not found!");
			}
			else {
				Set ip=wordMean.entrySet();
				Iterator op=ip.iterator();
				while(op.hasNext()) {
					System.out.println(op.next());
				}
			}
		} catch (NullPointerException e) {
			
			System.out.println("Dictionary is empty!");
		}
	}
}
